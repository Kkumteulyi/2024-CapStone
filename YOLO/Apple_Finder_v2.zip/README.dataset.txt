# apples > 2023-02-07 2:42pm
https://universe.roboflow.com/ds-lxa2d/apples-daz2v

Provided by a Roboflow user
License: CC BY 4.0

